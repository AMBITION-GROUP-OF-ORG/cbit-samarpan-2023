export const gallery_data=[{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/gallery-samarpan/im1.jpg?raw=true",visible:"true"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/gallery-samarpan/img6.jpeg?raw=true",visible:"false"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/gallery-samarpan/invitation.jpeg?raw=true",visible:"false"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/gallery-samarpan/img5.jpeg?raw=true",visible:"false"}]; 
