import "./footer.css";
export default function Footer(){
	return(
	<>
	<div className="w3-hover-ios-red  w3-padding-16  w3-grey w3-container">
	<div className="w3-serif" ><strong ><h5 style={{textAlign:"right"}}> Designed by Karthik M,Shreyas ,Prashanth Reddy, Dept of ECE ,CBIT Kolar</h5> </strong></div></div>
	</>);
}
