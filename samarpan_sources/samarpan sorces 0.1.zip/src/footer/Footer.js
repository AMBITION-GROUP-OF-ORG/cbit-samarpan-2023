
export default function Footer(){
	return(
	<>
	<div className="w3-hover-ios-red  w3-padding-4  w3-container" style={{backgroundColor:"#c7c4e9"}}>
	<div className="w3-serif" ><strong ><h5 style={{textAlign:"right",fontSize:"10px"}}> Designed by Prashanth Reddy,Karthik M,Shreyas ,ECE Dept.,CBIT Kolar</h5> </strong></div></div>
	</>);
}
