export default function Notification(){
    return (<>
    <div className="w3-card w3-container">
    <h3>New Notification 3:12 PM 11/05/2023</h3>
    <img className="w3-image w3-responsive" src="https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/IMG01.jpg?raw=true" alt="noti_image"/>
    </div>
    </>)
}