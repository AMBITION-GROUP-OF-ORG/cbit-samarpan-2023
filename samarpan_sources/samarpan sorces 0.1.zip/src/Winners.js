export default function Winners(){
	return(
		<div className="w3-container w3-center w3-black w3-padding-64">
		<h1>THIS PAGE WILL BE AVAILABLE AFTER EVENT STARTS</h1>
		<br /><br /><br /><br /><br /><br /><br /><br /><br />
		</div>

		);
}