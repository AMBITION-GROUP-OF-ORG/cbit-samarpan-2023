export const lazy_load=[{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/home_blur/im1.jpg?raw=true",visible:"true"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/home_blur/img6.jpeg?raw=true",visible:"false"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/home_blur/img5.jpeg?raw=true",visible:"false"},
							{link:"https://github.com/AMBITION-GROUP-OF-ORG/cbit-samarpan-2023/blob/main/home_blur/img5.jpeg?raw=true",visible:"false"}]; 
